
public class EmpNO {
	public static void main(String[] args) {
        LinkedList<Employees> linkedList = new LinkedList<Employees>(); // creation of Linked List
        
        linkedList.insertFirst(new Employees("11", "Abhi","a1"));
        linkedList.insertFirst(new Employees("12", "Kamesh","b1"));
        linkedList.insertFirst(new Employees("13", "Prakash","c1"));
        linkedList.insertFirst(new Employees("14", "Atul","d1"));
        linkedList.insertFirst(new Employees("15", "Shalini","e1"));

        linkedList.displayLinkedList();
  }
}
