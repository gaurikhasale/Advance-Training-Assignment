public abstract class Instruments {
    public abstract void Play();
    
}

